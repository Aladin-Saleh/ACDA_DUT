// juste un type énuméré pour nommer les bases
public enum Base {
    A,C,G,T
}
